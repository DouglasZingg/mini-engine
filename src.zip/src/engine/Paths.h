#pragma once
#include <string>

std::string AssetPath(const char* rel);
